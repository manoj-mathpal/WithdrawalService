package com.playfantasy.processbankwithdrawal.service;

import java.nio.charset.Charset;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.entity.ContentType;
import org.springframework.stereotype.Service;
import com.playfantasy.processbankwithdrawal.helper.Helper;
import com.playfantasy.processbankwithdrawal.model.RestResponse;

@Service
public class WithdrawOperationsService {

	static Map<String, String> headers = new LinkedHashMap<String, String>();

	static {

		final String userpass = "admin" + ":" + "secret";
		byte[] encodedAuth = Base64.encodeBase64(userpass.getBytes(Charset.forName("US-ASCII")));
		String authHeader = "Basic " + new String(encodedAuth);
		headers.put("Accept", "application/json");
		headers.put("Content-Type", "application/json");
		headers.put("AUTHORIZATION", authHeader);
		headers.put("Content-Type", "application/json");

	}

	public static RestResponse approvingAWithdrawRequest(long withdrawId, int type) {
		
		RestResponse restResponse = null;
		final String UNDER_PROCESSING = "{ \"context\": {}, \"status\":\"UNDER_PROCESSING\",\"type\":" + type + "}";
		final String UNDER_REVIEW = "{ \"context\": {}, \"status\": \"UNDER_REVIEW\",\"type\":"+ type +"}";
		final String APPROVED = "{ \"context\": {}, \"status\": \"APPROVED\",\"type\":"+ type +"}";
		String url = "http://192.168.6.18:8080/ups/api/userprofileservice/withdraw/" + withdrawId;

		Helper.perform_put(url, UNDER_PROCESSING, ContentType.APPLICATION_JSON, headers);
        Helper.perform_put(url, UNDER_REVIEW, ContentType.APPLICATION_JSON, headers);
        restResponse = Helper.perform_put(url, APPROVED, ContentType.APPLICATION_JSON, headers);

		System.out.println();
		return restResponse;

	}

	public static RestResponse markingWithdrawReqCreditedOnline(long withdrawId, int type) {

		final String PROCESSED = "{ \"context\": {}, \"status\": \"PROCESSED\",\"type\":" + type + "}";
		final String CREDITED_ONLINE = "{ \"context\": {}, \"status\": \"CREDITED_ONLINE\",\"type\":" + type + "}";
        String url = "http://192.168.6.18:8080/ups/api/userprofileservice/withdraw/" + withdrawId;
        
		System.out.println(url);
		Helper.perform_put(url, PROCESSED, ContentType.APPLICATION_JSON, headers);
		RestResponse restresponse = Helper.perform_put(url, CREDITED_ONLINE, ContentType.APPLICATION_JSON, headers);
		System.out.println(restresponse.toString());

		return restresponse;

	}

	public static RestResponse markingWithdrawReqFailedOnline(long withdrawId, int type) {

		final String PROCESSED = "{ \"context\": {}, \"status\": \"PROCESSED\",\"type\":" + type + "}";
		final String FAILED_ONLINE = "{ \"context\": {}, \"status\": \"FAILED_ONLINE\",\"type\":" + type + "}";
		String url = "http://192.168.6.18:8080/ups/api/userprofileservice/withdraw/" + withdrawId;

		Helper.perform_put(url, PROCESSED, ContentType.APPLICATION_JSON, headers);
		RestResponse restresponse = Helper.perform_put(url, FAILED_ONLINE, ContentType.APPLICATION_JSON, headers);
		System.out.println(restresponse.toString());

		return restresponse;

	}

	public static RestResponse markingWithdrawReqON_Hold(long withdrawId, int type) {

		final String UNDER_PROCESSING = "{ \"context\": {}, \"status\":\"UNDER_PROCESSING\",\"type\":" + type + "}";
		final String ON_HOLD = "{ \"context\": {}, \"status\": \"ON_HOLD\",\"type\":" + type + "}";
		String url = "http://192.168.6.18:8080/ups/api/userprofileservice/withdraw/" + withdrawId;

		Helper.perform_put(url, UNDER_PROCESSING, ContentType.APPLICATION_JSON, headers);
		RestResponse restresponse = Helper.perform_put(url, ON_HOLD, ContentType.APPLICATION_JSON, headers);
		System.out.println(restresponse.toString());

		return restresponse;
	}

}
