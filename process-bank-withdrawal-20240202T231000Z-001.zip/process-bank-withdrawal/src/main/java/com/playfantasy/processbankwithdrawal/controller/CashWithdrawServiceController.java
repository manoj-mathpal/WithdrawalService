package com.playfantasy.processbankwithdrawal.controller;

import java.io.File;
import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.playfantasy.processbankwithdrawal.service.CashWithdrawService;


@RestController
public class CashWithdrawServiceController {

	@Autowired
	 CashWithdrawService service;

	@GetMapping(path = "/withdraw/user/bankids")
	public List<BigInteger> getBankWithdrawIds() {
		List<BigInteger> list = service.getBankWithdrawalIds();
		return list;
	}

	@GetMapping(path = "/withdraw/user/referral/{user_id}")
	public List<?> getUserReferrals(@PathVariable int user_id) {
		List<BigInteger> lis = service.getUserReferrals(user_id);
		return lis;

	}

	@GetMapping(path = "/withdraw/user/woncontest/{user_id}")
	public List<Integer> getUserWonContests(@PathVariable int user_id) {
		List<Integer> li = service.contestsWonByUser(user_id);
		return li;

	}

	@GetMapping(path = "/withdraw/user/check/{user_id}")
	public String testContestGameplay(@PathVariable int user_id) {
		String fraud = service.gamePlayCheck(user_id);
		return fraud;

	}

	@GetMapping(path = "/withdraw/user/check/bankApprovedWithdrawals")
	public File approvedBankWithdrawals() {
		File file = null;

		try {
			file = service.csv();

		} catch (Exception e) {

			e.printStackTrace();
		}
		return file;
	}
	
	
	

}