package com.playfantasy.processbankwithdrawal.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.playfantasy.processbankwithdrawal.helper.BankNames;
import com.playfantasy.processbankwithdrawal.helper.EntityHelper;
import com.playfantasy.processbankwithdrawal.helper.Helper;
import com.playfantasy.processbankwithdrawal.model.RestResponse;

@SuppressWarnings("unchecked")
@Repository
public class CashWithdrawService {

	//@Autowired
	private EntityHelper serv;

	//@PersistenceContext
	private EntityManager entityManager;

	public List<Integer> contestsWonByUser(int user_id) {

		List<Integer> totalContest = new ArrayList<Integer>();

		List<Integer> Contest_user_won_before_Archive;

		List<Integer> Contest_user_won_afterArchive;

		String sql = "select DISTINCT sourceid from cash_transaction where uid= " + user_id + " and txn_head=3";
		Query query = serv.executeQuery(sql);
		Contest_user_won_afterArchive = serv.getIntTypelist(query.toString());

		for (int i = 0; i < Contest_user_won_afterArchive.size(); i++) {
			totalContest.add(Contest_user_won_afterArchive.get(i));
		}

		String sql1 = "select DISTINCT sourceid from ar_cash_transaction where uid= " + user_id + " and txn_head=3";
		Query query1 = serv.executeQuery(sql1);
		Contest_user_won_before_Archive = serv.getIntTypelist(query1.toString());

		for (int j = 0; j < Contest_user_won_before_Archive.size(); j++) {
			totalContest.add(Contest_user_won_before_Archive.get(j));
		}

		System.out.println("contest won by user");
		for (int j1 = 0; j1 < totalContest.size(); j1++) {
			System.out.println(totalContest.get(j1));

		}
		return totalContest;

	}

	public List<BigInteger> getBankWithdrawalIds() {

		List<BigInteger> WithdrawalsUserId;

		Query query = entityManager.createNativeQuery(
				"select id from cash_withdraw_request where type in (0,1) and status=1 and user_id>1000 ");

		WithdrawalsUserId = query.getResultList();

		return WithdrawalsUserId;

	}

	public List<Integer> contestWonByUserId(int user_id) {

		List<Integer> totalContest = new ArrayList<Integer>();
		List<Integer> Contest_user_won_before_Archive;
		List<Integer> Contest_user_won_afterArchive;

		Query query1 = entityManager.createNativeQuery(
				"select DISTINCT sourceid from cash_transaction where txn_head=3 and uid=" + user_id);

		Contest_user_won_afterArchive = query1.getResultList();

		for (int i = 0; i < Contest_user_won_afterArchive.size(); i++) {
			totalContest.add(Contest_user_won_afterArchive.get(i));
		}

		Query query2 = entityManager.createNativeQuery(
				"select DISTINCT sourceid from ar_cash_transaction where txn_head=3 and uid=" + user_id);

		Contest_user_won_before_Archive = query2.getResultList();

		for (int j = 0; j < Contest_user_won_before_Archive.size(); j++) {
			totalContest.add(Contest_user_won_before_Archive.get(j));
		}

		return totalContest;

	}

	public String gamePlayCheck(int user_id) {

		List<Integer> totalContest = new ArrayList<Integer>();
		ArrayList<Integer> fraudContest = new ArrayList<Integer>();

		List<BigInteger> userReferrals;
		List<Integer> Contest_user_won_before_Archive;
		List<Integer> Contest_user_won_afterArchive;

		int fairContestCount = 0;
		int referral_registration_count = 0;
		String status = null;

		Query query = entityManager
				.createNativeQuery("select referral_id from player_referral_details where referred_id=" + user_id);

		userReferrals = query.getResultList();

		Query query1 = entityManager.createNativeQuery(
				"select DISTINCT sourceid from cash_transaction where txn_head=3 and uid=" + user_id);

		Contest_user_won_afterArchive = query1.getResultList();

		for (int i = 0; i < Contest_user_won_afterArchive.size(); i++) {
			totalContest.add(Contest_user_won_afterArchive.get(i));
		}

		Query query2 = entityManager.createNativeQuery(
				"select DISTINCT sourceid from ar_cash_transaction where txn_head=3 and uid=" + user_id);

		Contest_user_won_before_Archive = query2.getResultList();

		for (int j = 0; j < Contest_user_won_before_Archive.size(); j++) {
			totalContest.add(Contest_user_won_before_Archive.get(j));
		}

		int no_of_total_contest = totalContest.size();

		for (int q = 0; q < totalContest.size(); q++) {

			List<BigInteger> totalUsers = new ArrayList<BigInteger>();
			List<BigInteger> totalUsersAfterArchive;
			List<BigInteger> totalUsersBeforeArchive;

			Query query3 = entityManager.createNativeQuery(
					"select user_id from contest_registrations where contest_id=" + totalContest.get(q));

			totalUsersAfterArchive = query3.getResultList();

			for (int i1 = 0; i1 < totalUsersAfterArchive.size(); i1++) {
				totalUsers.add(totalUsersAfterArchive.get(i1));
			}

			Query query4 = entityManager.createNativeQuery(
					"select user_id from ar_contest_registrations where contest_id=" + totalContest.get(q));

			totalUsersBeforeArchive = query4.getResultList();

			for (int i2 = 0; i2 < totalUsersBeforeArchive.size(); i2++) {
				totalUsers.add(totalUsersBeforeArchive.get(i2));
			}

			int total_contest_registrations = totalUsers.size();

			for (int k1 = 0; k1 < totalUsers.size(); k1++) {

				for (int k = 0; k < userReferrals.size(); k++) {

					if (userReferrals.get(k).equals(totalUsers.get(k1))) {

						referral_registration_count++;

					}

				}

			}

			if (referral_registration_count < total_contest_registrations / 2 || referral_registration_count == 0) {
				fairContestCount++;

			}

			else {

				fraudContest.add(totalContest.get(q));

			}

			referral_registration_count = 0;

		}

		if (fairContestCount == no_of_total_contest && referral_registration_count == 0) {

			status = "true";
			return status;

		}

		else {

			Float amountPayed = 0f;
			Float amountWon = 0f;
			List<BigDecimal> bonusAllowed;
			List<BigInteger> visibility;
			int pluscnt = 0;
			int negcnt = 0;

			for (int n = 0; n < fraudContest.size(); n++) {
				System.out.println(fraudContest.get(n));

				Query query4 = entityManager
						.createNativeQuery("select visibility_id from contest where id =" + fraudContest.get(n));

				visibility = query4.getResultList();

				int contest_visibility = visibility.get(0).intValueExact();
				BigDecimal bonus_allowed = null;

				if (contest_visibility == 1) {

					Query query5 = entityManager
							.createNativeQuery("select bonus_allowed from contest where id =" + fraudContest.get(n));

					bonusAllowed = query5.getResultList();

					bonus_allowed = bonusAllowed.get(0);

					if (bonus_allowed.equals(0)) {
						status = "PASSED";
						System.out.println(" contest " + fraudContest.get(n) + " visibility " + contest_visibility
								+ " bonus " + bonus_allowed);

					} else {

						Query query6 = entityManager
								.createNativeQuery("select sum(txn_amt) from cash_transaction where uid=" + user_id
										+ " and txn_head=1 and sourceid=" + fraudContest.get(n));

						List<Float> list2 = query6.getResultList();
						for (int g2 = 0; g2 < list2.size(); g2++) {
							amountPayed = list2.get(g2);
						}

						Query query7 = entityManager
								.createNativeQuery("select sum(txn_amt) from cash_transaction where uid=" + user_id
										+ " and  txn_head=3 and sourceid=" + fraudContest.get(n));

						List<Float> list3 = query7.getResultList();
						for (int g3 = 0; g3 < list3.size(); g3++) {
							amountWon = list3.get(g3);
						}

					}

				}

				else {

					status = "PASSED";

					return status;
				}

				float totalAmountPlayed = (amountPayed * 2);

				if (amountWon < totalAmountPlayed) {

					pluscnt++;
				}

				else {
					negcnt++;
				}

				System.out.println(" contest " + fraudContest.get(n) + " visibility " + visibility.get(0) + " bonus "
						+ bonusAllowed.get(0) + " amount played " + totalAmountPlayed + " won " + amountWon);
			}

			if (negcnt == 0) {
				status = "PASSED";
			} else {
				status = "FAILED";
			}

		}
		return status;
	}

	public List<BigInteger> getUserReferrals(int user_id) {

		List<BigInteger> userReferrals = new ArrayList<>();

//		Query query = entityManager
//				.createNativeQuery("select referral_id from player_referral_details where referred_id=" + user_id);
//
//		userReferrals = query.getResultList();

		System.out.println("referrals of users");
		for (int c = 0; c < 10; c++) {
			userReferrals.add(BigInteger.valueOf(c));
			System.out.println(c);
		}

		return userReferrals;
	}

	public File csv() throws IOException, ParseException {

		List<BigInteger> withdrawId;
		List<BigInteger> userId;
		List<BigDecimal> amount;

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todays_date = formatter.format(date);
		FileWriter writer = null;
		// select * from cash_withdraw_request where status=7 and type in(0,1) and
		// user_id>1000 and last_updated>=(now()- interval '1 days')

		Query query1 = entityManager.createNativeQuery(
				"select id  from cash_withdraw_request where status=7 and type in(0,1) and user_id>1000 and last_updated>=(now()- interval '1 days')");

		withdrawId = query1.getResultList();
		Query query2 = entityManager.createNativeQuery(
				"select user_id  from cash_withdraw_request where status=7 and type in(0,1) and user_id>1000 and last_updated>=(now()- interval '1 days')");

		userId = query2.getResultList();

		Query query3 = entityManager.createNativeQuery(
				"select amount  from cash_withdraw_request where status=7 and type in(0,1) and user_id>1000 and last_updated>=(now()- interval '1 days')");

		amount = query3.getResultList();

		writer = new FileWriter("opp.txt");



		for (int i = 0; i < withdrawId.size(); i++) {

			String txn_head = "N";

						RestResponse response = Helper.perform_Get(
					"http://192.168.6.18:8080/ups/api/userprofileservice/users?s=user_id%3D%3D" + userId.get(i));
			String str = response.getResponseBody();

			JSONParser parser = new JSONParser();
			JSONArray json = null;

			json = (JSONArray) parser.parse(str);

			String first_name = (String) ((JSONObject) ((JSONObject) json.get(0)).get("address")).get("first_name");
			String last_name = (String) ((JSONObject) ((JSONObject) json.get(0)).get("address")).get("last_name");
			String email = (String) (((JSONObject) json.get(0)).get("email"));

			String acc_no = (String) ((JSONObject) ((JSONObject) json.get(0)).get("bank")).get("account_number");

			String ifsc_no = (String) ((JSONObject) ((JSONObject) json.get(0)).get("bank")).get("ifsc_code");

			String name = first_name + last_name;

			String bank_name = BankNames.bankFinder(ifsc_no);

			if (ifsc_no.substring(0, 4).equals("HDFC")) {
				txn_head = "I";
			}

			try {

				writer.write(txn_head);

				writer.write(",");

				writer.write((name.substring(0, 5) + userId.get(i)).trim());
				writer.write(",");

				writer.write(acc_no);
				writer.write(",");

				writer.write(amount.get(i)+"");
				writer.write(",");
				if (last_name != null) {
					writer.write(first_name + " " + last_name);
				} else {
					writer.write(first_name);
				}
				writer.write(",,,,,,,,,");
				writer.write((name.substring(0, 5) + userId.get(i)).trim());
				writer.write(",,,,,,,,,");
				writer.write(todays_date);
				writer.write(",,");

				writer.write(ifsc_no);
				writer.write(",");

				writer.write(bank_name);
				writer.write(",,");

				writer.write(email);

				writer.write("\r\n");

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		writer.close();

		System.out.println("file created");

		File file = new File("C:\\Users\\server\\Desktop\\up\\process-bank-withdrawal\\nnnnn.txt");
		System.out.println("---------------------------------------------" + file.exists());
		return file;

	}

}
