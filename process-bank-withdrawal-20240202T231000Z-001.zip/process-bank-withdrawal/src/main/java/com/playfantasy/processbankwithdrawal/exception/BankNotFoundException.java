package com.playfantasy.processbankwithdrawal.exception;

public class BankNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	
	
	public BankNotFoundException(String str) {
		super("BANK NAME NOT FOUND FOR THIS IFSC CODE " +str);
	}

}
