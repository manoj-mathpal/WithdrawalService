package com.playfantasy.processbankwithdrawal.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.playfantasy.processbankwithdrawal.helper.BankNames;
import com.playfantasy.processbankwithdrawal.helper.EntityHelper;
import com.playfantasy.processbankwithdrawal.helper.Helper;
import com.playfantasy.processbankwithdrawal.model.RestResponse;

@Repository
public class BankWithdrawal {

	//@Autowired
	private EntityHelper service;


	public List<BigInteger> getBankWithdrawalIds() {

		String sql = "select id from cash_withdraw_request where type in (0,1) and status=1 and user_id>1000";
		List<BigInteger> WithdrawalsUserId = service.getBigIntTypelist(sql);
		return WithdrawalsUserId;
	}

	public List<Integer> contestWonByUser(int user_id) {

		String sql = "SELECT sourceid FROM cash_transaction where txn_head=3 and uid=" + user_id
				+ " UNION ALL SELECT sourceid FROM ar_cash_transaction where txn_head=3 and uid=" + user_id;
		List<Integer> totalContest = service.getIntTypelist(sql);
		return totalContest;

	}

	public List<BigInteger> getUserReferrals(int user_id) {

		String sql = "select referral_id from player_referral_details where referred_id=" + user_id;
		List<BigInteger> userReferrals = service.getBigIntTypelist(sql);
		return userReferrals;

	}

	public String gamePlayCheck(int user_id) {

		ArrayList<Integer> fraudContest = new ArrayList<Integer>();

		List<BigInteger> userReferrals;

		int fairContestCount = 0;
		int referral_registration_count = 0;
		String status = null;

		String sql1 = "select referral_id from player_referral_details where referred_id=" + user_id;
		userReferrals = service.getBigIntTypelist(sql1);

		String sql2 = "SELECT sourceid FROM cash_transaction where txn_head=3 and uid=" + user_id
				+ " UNION ALL SELECT sourceid FROM ar_cash_transaction where txn_head=3 and uid=" + user_id;
		List<Integer> totalContest = service.getIntTypelist(sql2);

		int no_of_total_contest = totalContest.size();

		for (int q = 0; q < totalContest.size(); q++) {

			String sql3 = "SELECT user_id FROM contest_registrations where contest_id=" + totalContest.get(q)
					+ "UNION ALL SELECT user_id FROM ar_contest_registrations where contest_id=" + totalContest.get(q);
			List<BigInteger> totalUsers = service.getBigIntTypelist(sql3);

			int total_contest_registrations = totalUsers.size();

			for (int k1 = 0; k1 < totalUsers.size(); k1++) {

				for (int k = 0; k < userReferrals.size(); k++) {

					if (userReferrals.get(k).equals(totalUsers.get(k1))) {

						referral_registration_count++;

					}

				}

			}

			if (referral_registration_count < total_contest_registrations / 2 || referral_registration_count == 0) {
				fairContestCount++;

			}

			else {

				fraudContest.add(totalContest.get(q));

			}

			referral_registration_count = 0;

		}

		if (fairContestCount == no_of_total_contest && referral_registration_count == 0) {

			status = "true";
			return status;

		}

		else {

			Float amountPayed = 0f;
			Float amountWon = 0f;
			List<BigDecimal> bonusAllowed;
			List<BigInteger> visibility;
			int pluscnt = 0;
			int negcnt = 0;

			for (int n = 0; n < fraudContest.size(); n++) {
				System.out.println(fraudContest.get(n));

				String sql4 = "select visibility_id from contest where id =" + fraudContest.get(n);
				visibility = service.getBigIntTypelist(sql4);
				int contest_visibility = visibility.get(0).intValueExact();

				BigDecimal bonus_allowed = null;

				if (contest_visibility == 1) {

					String sql5 = "select bonus_allowed from contest where id =" + fraudContest.get(n);
					bonusAllowed = service.getBigDecTypelist(sql5);

					bonus_allowed = bonusAllowed.get(0);

					if (bonus_allowed.equals(0)) {
						status = "PASSED";
						System.out.println(" contest " + fraudContest.get(n) + " visibility " + contest_visibility
								+ " bonus " + bonus_allowed);

					} else {

						String sql6 = "select sum(txn_amt) from cash_transaction where uid=" + user_id
								+ "and txn_head=1 and sourceid=" + fraudContest.get(n);

						List<Float> list2 = service.getFloatTypelist(sql6);
						for (int g2 = 0; g2 < list2.size(); g2++) {
							amountPayed = list2.get(g2);
						}

						String sql7 = "select sum(txn_amt) from cash_transaction where uid=" + user_id
								+ " and  txn_head=3 and sourceid =" + fraudContest.get(n);
						List<Float> list3 = service.getFloatTypelist(sql7);
						for (int g3 = 0; g3 < list3.size(); g3++) {
							amountWon = list3.get(g3);
						}

					}

				}

				else {

					status = "PASSED";

					return status;
				}

				float totalAmountPlayed = (amountPayed * 2);

				if (amountWon < totalAmountPlayed) {

					pluscnt++;
				}

				else {
					negcnt++;
				}

				System.out.println(" contest " + fraudContest.get(n) + " visibility " + visibility.get(0) + " bonus "
						+ bonusAllowed.get(0) + " amount played " + totalAmountPlayed + " won " + amountWon);
			}

			if (negcnt == 0) {
				status = "PASSED";
			} else {
				status = "FAILED";
			}

		}
		return status;
	}

	public File generateApprovedWithdrawalIdsTextFile() throws IOException, ParseException {

		List<BigInteger> withdrawId;
		List<BigInteger> userId;
		List<BigDecimal> amount;

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todays_date = formatter.format(date);
		FileWriter writer = null;

		String sql1 = "select id  from cash_withdraw_request where status=7 and type in(0,1) and user_id>1000 and last_updated>=(now()- interval '1 days')";
		withdrawId = service.getBigIntTypelist(sql1);

		String sql2 = "select user_id  from cash_withdraw_request where status=7 and type in(0,1) and user_id>1000 and last_updated>=(now()- interval '1 days')";
		userId = service.getBigIntTypelist(sql2);

		String sql3 = "select amount  from cash_withdraw_request where status=7 and type in(0,1) and user_id>1000 and last_updated>=(now()- interval '1 days')";
		amount = service.getBigDecTypelist(sql3);

		writer = new FileWriter("withdrawaltextfile.txt");

		for (int i = 0; i < withdrawId.size(); i++) {

			String txn_head = "N";

			RestResponse response = Helper.perform_Get(
					"http://192.168.6.18:8080/ups/api/userprofileservice/users?s=user_id%3D%3D" + userId.get(i));
			String str = response.getResponseBody();

			JSONParser parser = new JSONParser();
			JSONArray json = null;

			json = (JSONArray) parser.parse(str);

			String first_name = (String) ((JSONObject) ((JSONObject) json.get(0)).get("address")).get("first_name");
			String last_name = (String) ((JSONObject) ((JSONObject) json.get(0)).get("address")).get("last_name");
			String email = (String) (((JSONObject) json.get(0)).get("email"));

			String acc_no = (String) ((JSONObject) ((JSONObject) json.get(0)).get("bank")).get("account_number");

			String ifsc_no = (String) ((JSONObject) ((JSONObject) json.get(0)).get("bank")).get("ifsc_code");

			String name = first_name + last_name;

			String bank_name = BankNames.bankFinder(ifsc_no);

			if (ifsc_no.substring(0, 4).equals("HDFC")) {
				txn_head = "I";
			}

			try {

				writer.write(txn_head);

				writer.write(",");

				writer.write((name.substring(0, 5) + userId.get(i)).trim());
				writer.write(",");

				writer.write(acc_no);
				writer.write(",");

				writer.write(amount.get(i) + "");
				writer.write(",");

				if (last_name != null) {
					writer.write(first_name + " " + last_name);
				} else {
					writer.write(first_name);
				}

				writer.write(",,,,,,,,,");
				writer.write((name.substring(0, 5) + userId.get(i)).trim());
				writer.write(todays_date);
				writer.write(",,");

				writer.write(ifsc_no);
				writer.write(",");

				writer.write(bank_name);
				writer.write(",,");

				writer.write(email);

				writer.write("\r\n");

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		writer.close();

		System.out.println("file created");
		File file = new File("home/algorin/Documents/process-bank-withdrawal/opp.txt");
		System.out.println("does file exist " + file.exists());
		return file;

	}

}
