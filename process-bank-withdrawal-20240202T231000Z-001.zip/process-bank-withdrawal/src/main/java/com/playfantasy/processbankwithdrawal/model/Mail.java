package com.playfantasy.processbankwithdrawal.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Mail {
	
	private String from;

	private List<String> to;

	private List<String> cc;

	private String subject;

	private String message;

	public Mail() {
		this.to = new ArrayList<String>();
		this.cc = new ArrayList<String>();
	}

	public Mail(String from, String toList, String subject, String message) {
		this();
		this.from = from;
		this.subject = subject;
		this.message = message;
		this.to.addAll(Arrays.asList(splitByComma(toList)));
	}

	public Mail(String from, String toList, String ccList, String subject, String message) {
		this();
		this.from = from;
		this.subject = subject;
		this.message = message;
		this.to.addAll(Arrays.asList(splitByComma(toList)));
		this.cc.addAll(Arrays.asList(splitByComma(ccList)));
	}

	private String[] splitByComma(String toMultiple) {
		String[] toSplit = toMultiple.split(",");
		return toSplit;
	}



}
