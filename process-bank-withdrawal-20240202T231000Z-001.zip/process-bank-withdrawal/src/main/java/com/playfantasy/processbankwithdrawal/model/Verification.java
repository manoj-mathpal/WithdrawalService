package com.playfantasy.processbankwithdrawal.model;

public class Verification {

	private long user_id;
	private boolean autoProcess_status;
	private boolean commonContestPass_status;

	public Verification(long user_id, boolean autoProcess_status, boolean commonContestPass_status) {
		super();
		this.user_id=user_id;
		this.autoProcess_status = autoProcess_status;
		this.commonContestPass_status = commonContestPass_status;
	}

	public long getUser_id() {
		return user_id;
	}

	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}

	public boolean isAutoProcess_status() {
		return autoProcess_status;
	}

	public void setAutoProcess_status(boolean autoProcess_status) {
		this.autoProcess_status = autoProcess_status;
	}

	public boolean isCommonContestPass_status() {
		return commonContestPass_status;
	}

	public void setCommonContestPass_status(boolean commonContestPass_status) {
		this.commonContestPass_status = commonContestPass_status;
	}

	@Override
	public String toString() {
		return "Verification [user_id=" + user_id + ", autoProcess_status=" + autoProcess_status
				+ ", commonContestPass_status=" + commonContestPass_status + "]";
	}
	
	

	
	

}
