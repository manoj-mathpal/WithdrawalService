package com.playfantasy.processbankwithdrawal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.playfantasy.processbankwithdrawal.model.User;
import com.playfantasy.processbankwithdrawal.service.UserService;


@RestController
public class UserController {
	
	

	@Autowired
	private UserService obj;

//	@GetMapping(path = "/user/verification/check/{user_id}")
//	public User verifyUser(@PathVariable int user_id) {
//
//		User u = obj.verifyUser(user_id);
//		u.toString();
//		return u;
//
//
//
//	}
	

}
