package com.playfantasy.processbankwithdrawal.service;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.kie.api.runtime.KieContainer;
	import org.kie.api.runtime.StatelessKieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.playfantasy.processbankwithdrawal.helper.Helper;
import com.playfantasy.processbankwithdrawal.model.RestResponse;
import com.playfantasy.processbankwithdrawal.model.User;


@Service
public class UserService {
	
//	//@Autowired
//	private KieContainer kieContainer;
//
//
//	public User verifyUser(int user_id) {
//		User user = new User();
//				RestResponse response = Helper
//				.perform_Get("http://192.168.6.18:8080/ups/api/userprofileservice/users?s=user_id%3D%3D" +user_id);
//		String str = response.getResponseBody();
//
//
//
//		JSONParser parser = new JSONParser();
//		JSONArray json = null;
//
//		try {
//			json = (JSONArray) parser.parse(str);
//		} catch (ParseException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//
//
//
//
//		try {
//			long id = (long) ( ((JSONObject) json.get(0)).get("id"));
//			 int userid = (int) id;
//			user.setId(userid);
//			String status = (String) ( ((JSONObject) json.get(0)).get("status"));
//			user.setUserStatus(status);
//			String pan_status = (String) ((JSONObject) ((JSONObject) json.get(0)).get("authorizations"))
//					.get("pan_verification");
//			user.setPanVerified(pan_status);
//			boolean email_verification = (boolean) ((JSONObject) ((JSONObject) json.get(0)).get("authorizations"))
//					.get("email_verification");
//			user.setEmailVerified(email_verification);
//			boolean mobile_verification = (boolean) ((JSONObject) ((JSONObject) json.get(0)).get("authorizations"))
//					.get("mobile_verification");
//			user.setEmailVerified(mobile_verification);
//
//			double withdraw_bucket = (double) ((JSONObject) ((JSONObject) json.get(0)).get("cashAccount"))
//					.get("withdrawable");
//			user.setWithdrawBucket(withdraw_bucket);
//
//			System.out.println(status);
//			System.out.println(pan_status);
//			System.out.println(email_verification);
//			System.out.println(mobile_verification);
//			System.out.println(withdraw_bucket);
//
//			return details(user);
//		}
//		catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		/*try {
//		String status = (String) ( ((JSONObject) json.get(0)).get("status"));
//		user.setUserStatus(status);
//		String pan_status = (String) ((JSONObject) ((JSONObject) json.get(0)).get("authorizations"))
//				.get("pan_verification");
//		user.setPanVerified(pan_status);
//		String email_verification = (String) ((JSONObject) ((JSONObject) json.get(0)).get("authorizations"))
//				.get("email_verification");
//		user.setEmailVerified(email_verification);
//		String mobile_verification = (String) ((JSONObject) ((JSONObject) json.get(0)).get("authorizations"))
//				.get("mobile_verification");
//		user.setEmailVerified(mobile_verification);
//
//		double withdraw_bucket = (double) ((JSONObject) ((JSONObject) json.get(0)).get("cashAccount"))
//				.get("withdrawable");
//		user.setWithdrawBucket(withdraw_bucket);
//
//		System.out.println(status);
//		System.out.println(pan_status);
//		System.out.println(email_verification);
//		System.out.println(mobile_verification);
//		System.out.println(withdraw_bucket);
//
//		return details(user);
//		}
//		catch (Exception e) {
//			e.getMessage();
//		}*/
//		return user;
//
//
//	}
//
//
//	public User details(User user) {
//		StatelessKieSession kieSession = kieContainer.newStatelessKieSession();
//		kieSession.setGlobal("user", user);
//		kieSession.execute(user);
//		return user;
//	}

}
