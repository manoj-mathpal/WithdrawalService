package com.playfantasy.processbankwithdrawal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class UserActionServiceController {
	
	
	@Autowired
	UserActionServiceController userActionService;
	
	
	@PostMapping("/update/user_status/block/{user_id}")
	public String blockUser(@PathVariable int user_id) {
		String rest = userActionService.blockUser(user_id);
		return rest;
	}
	
	@PostMapping("/update/user_status/unblock/{user_id}")
	public String unblockUser(@PathVariable int user_id) {
		String rest = userActionService.unblockUser(user_id);
		return rest;
	}

}
