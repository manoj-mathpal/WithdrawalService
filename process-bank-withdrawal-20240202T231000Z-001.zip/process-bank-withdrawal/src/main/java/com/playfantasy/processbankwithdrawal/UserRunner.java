package com.playfantasy.processbankwithdrawal;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.playfantasy.processbankwithdrawal.service.CashWithdrawService;

@Component
public class UserRunner implements CommandLineRunner {

	
	//@Autowired
	CashWithdrawService ser;

	@Override
	public void run(String... args) throws Exception {

//		File ff = ser.csv();
//		ff.toString();
	}

	
}
