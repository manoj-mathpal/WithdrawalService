package com.playfantasy.processbankwithdrawal.service;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.playfantasy.processbankwithdrawal.helper.Helper;
import com.playfantasy.processbankwithdrawal.model.BlockedUsersList;
import com.playfantasy.processbankwithdrawal.model.RestResponse;
import com.playfantasy.processbankwithdrawal.model.Verification;

@SuppressWarnings("unchecked")
@Service
public class UserVerificationService {

	@Autowired
	private BankWithdrawal service;

	private List<Integer> approvedUser = new ArrayList<Integer>();
	private List<Integer> blockedUser = new ArrayList<Integer>();
	private RestResponse response;


	public RestResponse userVerif(int withdrawId, int type) {
		response=null;
		Verification obj = callWithdrawUserSummaryApi(withdrawId);

		long user_id = obj.getUser_id();
		boolean auto_process = obj.isAutoProcess_status();
		boolean common_contest = obj.isCommonContestPass_status();

		System.out.println("userVerif");
		System.out.println(user_id);
		System.out.println(auto_process);
		System.out.println();
		System.out.println(common_contest);

		String userid_str = String.valueOf(user_id);
		int userid_int = (int) user_id;

		if (auto_process == true && common_contest == true) {

			response = WithdrawOperationsService.approvingAWithdrawRequest(withdrawId, type);
			if (response.getStatusCode() == 200)
				System.out.println("id approved");
			approvedUser.add(userid_int);
		}

		else if (auto_process == false && common_contest == true) {

			String status = captureBonusApiInfo(userid_str);

			if (status.equals("true")) {
			response = WithdrawOperationsService.approvingAWithdrawRequest(withdrawId, type);
				if (response.getStatusCode() == 200)
					System.out.println("id approved");
				approvedUser.add(userid_int);
			} else {
				WithdrawOperationsService.markingWithdrawReqON_Hold(withdrawId, type);
				 response = UserActionService.blockUserId(userid_int);
				if (response.getStatusCode() == 200) {
					System.out.println("id blocked");
					blockedUser.add(userid_int);
				}
			}
		}

		else if (auto_process == true && common_contest == false) {

			String status = service.gamePlayCheck(userid_int);

			if (status.equals("true") || status.equals("PASSED")) {
				 response = WithdrawOperationsService.approvingAWithdrawRequest(withdrawId, type);
				if (response.getStatusCode() == 200) {
					System.out.println("id approved");
					approvedUser.add(userid_int);
				}
			}

			else {

				WithdrawOperationsService.markingWithdrawReqON_Hold(withdrawId, type);
				 response = UserActionService.blockUserId(userid_int);

				if (response.getStatusCode() == 200) {
					System.out.println("id blocked");

					blockedUser.add(userid_int);
				}
			}
		}

		else {

			WithdrawOperationsService.markingWithdrawReqON_Hold(withdrawId, type);
			RestResponse response = UserActionService.blockUserId(userid_int);
			if (response.getStatusCode() == 200) {
				System.out.println("id blocked");

				blockedUser.add(userid_int);
			}
		}
		return response;

	}

	public Verification callWithdrawUserSummaryApi(int withdrawId) {

		RestResponse response = Helper
				.perform_Get("http://192.168.6.17:8080/person/withdraw-request/JSON/" + withdrawId);
		String str = response.getResponseBody().toString();

		JSONParser parser = new JSONParser();
		Object json = null;

		try {
			json = parser.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		JSONArray array = new JSONArray();
		array.add(json);

		System.out.println("callWithdrawUserSummaryApi");
		long user_id = (long) (((JSONObject) array.get(0)).get("user_id"));
		System.out.println(user_id);
		boolean autoProcess_status = (boolean) (((JSONObject) array.get(0)).get("autoProcess"));
		System.out.println(autoProcess_status);

		boolean commonContestPass_status = (boolean) (((JSONObject) array.get(0)).get("commonContestPass"));
		System.out.println(commonContestPass_status);

		return new Verification(user_id, autoProcess_status, commonContestPass_status);

	}

	public String captureBonusApiInfo(String user_id) {

		RestResponse response = Helper.perform_Get("http://192.168.6.17:8080/capture-bonus/" + user_id);
		String str = response.getResponseBody();
		int current_user = Integer.valueOf(user_id);
		JSONParser parser = new JSONParser();
		Object json = null;

		try {
			json = parser.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		JSONArray array = new JSONArray();
		array.add(json);

		System.out.println("captureBonusApi");

		String status = null;
		String connectedUser = ((String) (((JSONObject) array.get(0)).get("Connected Users")));
		System.out.println(connectedUser);
		String[] connecteduser = connectedUser.split(",");

		String ActiveIds = ((String) (((JSONObject) array.get(0)).get("Active Ids")));
		System.out.println(ActiveIds);
		String[] activeid = ActiveIds.split(",");
		System.out.println(activeid.length);
		System.out.println(connecteduser.length);
		int count = 0;

		while (count < activeid.length) {

			if (activeid.length == 1 && connecteduser.length == 1 && activeid[count] == user_id
					&& connecteduser[count] == user_id) {

				status = "true";
				System.out.println("1"+status);
				return status;

			}

			else if (activeid.length == 1 && connecteduser.length == 2) {
				ArrayList<Integer> unblocked_user = BlockedUsersList.blocked_userIds;

				System.out.println("unblocked users");
				for(int vv=0;vv<unblocked_user.size();vv++) {
					System.out.println(unblocked_user.get(vv));



					if (current_user == unblocked_user.get(vv)) {
						System.out.println("found");


						if (activeid[count] == user_id) {
							System.out.println("both active and userid are equal");
							status = "true";
							System.out.println("2"+status);
							break;
						}

						System.out.println("not equal");
					}

					status="false";
					return status;


				}

                  return status;
			}

			else if (activeid.length >= 2 && connecteduser.length >= 1) {
				System.out.println("blockeddd");

				status = "false";
				System.out.println(status);


			}
			count++;
		}
		return status;

	}

}
