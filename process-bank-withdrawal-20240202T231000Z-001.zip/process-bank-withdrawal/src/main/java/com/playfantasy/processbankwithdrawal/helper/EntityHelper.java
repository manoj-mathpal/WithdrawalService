package com.playfantasy.processbankwithdrawal.helper;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

//@Component
@SuppressWarnings("unchecked")
public class EntityHelper {

	//@PersistenceContext
	private EntityManager entityManager;
	EntityManagerFactory fac;

	public Query executeQuery(String sql) {

		Query queryz = entityManager.createNativeQuery(sql);
		return queryz;

	}

	public List<Integer> getIntTypelist(String sql) {

		Query query11 = entityManager.createNativeQuery(sql);
		List<Integer> list = query11.getResultList();
		return list;

	}

	public List<String> retrvStringDataFromQuery(String sql) {
		Query query11 = entityManager.createNativeQuery(sql);

		List<String> list = query11.getResultList();
		return list;

	}

	public List<BigInteger> getBigIntTypelist(String sql) {
		Query query11 = entityManager.createNativeQuery(sql);

		List<BigInteger> list = query11.getResultList();
		return list;

	}

	public List<BigDecimal> getBigDecTypelist(String sql) {
		Query query11 = entityManager.createNativeQuery(sql);

		List<BigDecimal> list = query11.getResultList();
		return list;

	}

	public List<Float> getFloatTypelist(String sql) {
		Query query11 = entityManager.createNativeQuery(sql);

		List<Float> list = query11.getResultList();
		return list;

	}


}
