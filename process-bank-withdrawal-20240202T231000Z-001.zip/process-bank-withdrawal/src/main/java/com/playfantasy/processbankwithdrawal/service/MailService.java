package com.playfantasy.processbankwithdrawal.service;

import java.io.File;
import java.io.IOException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailParseException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component
public class MailService {

	@Autowired
	private JavaMailSender sender;

	@Autowired
	private BankWithdrawal service;

	public File sendEmail() throws MessagingException {

		File file = null;
		try {
			file = service.generateApprovedWithdrawalIdsTextFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ParseException e1) {
			e1.printStackTrace();
		}

		MimeMessage message = sender.createMimeMessage();

		try {

			MimeMessageHelper helper = new MimeMessageHelper(message, true);

			helper.setTo("manojmthpl9@gmail.com");
			helper.setText("Hi");
			helper.setSubject("please find the attached file below");
			helper.addAttachment(file.getName(), file);

		} catch (MessagingException e) {
			throw new MailParseException(e);
		}

		sender.send(message);
		System.out.println("sent");
		return file;

	}
}
