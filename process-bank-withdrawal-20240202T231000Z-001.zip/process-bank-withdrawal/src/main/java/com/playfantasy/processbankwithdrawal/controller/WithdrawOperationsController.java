package com.playfantasy.processbankwithdrawal.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.playfantasy.processbankwithdrawal.model.RestResponse;
import com.playfantasy.processbankwithdrawal.service.WithdrawOperationsService;

@RestController
public class WithdrawOperationsController {

	@PutMapping("/update/bankWithdrawReq/Approved/{withdrawId}/{type}")
	public RestResponse approvingAWithdrawRequest(@PathVariable long withdrawId, @PathVariable int type) {
		RestResponse rest = WithdrawOperationsService.approvingAWithdrawRequest(withdrawId, type);
		return rest;
	}

	@PutMapping("/update/bankWithdrawReq/Credited-Online/{withdrawId}/{type}")
	public RestResponse markWithdrawReqCreditedOnline(@PathVariable long withdrawId, @PathVariable int type) {
		RestResponse rest = WithdrawOperationsService.markingWithdrawReqCreditedOnline(withdrawId, type);
		return rest;
	}

	@PutMapping("/update/bankWithdrawReq/Failed-Online/{withdrawId}/{type}")
	public RestResponse markWithdrawReqFailedOnline(@PathVariable long withdrawId, @PathVariable int type) {
		RestResponse rest = WithdrawOperationsService.markingWithdrawReqFailedOnline(withdrawId, type);
		return rest;
	}

	@PutMapping("/update/bankWithdrawReq/OnHold/{withdrawId}/{type}")
	public RestResponse markWithdrawReqON_Hold(@PathVariable long withdrawId, @PathVariable int type) {
		RestResponse rest = WithdrawOperationsService.markingWithdrawReqON_Hold(withdrawId, type);
		return rest;
	}

}
