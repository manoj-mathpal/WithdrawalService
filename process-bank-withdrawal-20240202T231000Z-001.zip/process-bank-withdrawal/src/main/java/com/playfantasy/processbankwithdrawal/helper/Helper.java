package com.playfantasy.processbankwithdrawal.helper;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.FileEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;

import com.playfantasy.processbankwithdrawal.model.RestResponse;

public class Helper {

	public static RestResponse perform_Get(String url) {
		try {
			return perform_Get(new URI(url));
		} catch (URISyntaxException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public static RestResponse perform_Get(URI uri) {

		HttpGet get = new HttpGet(uri);

		String userpass = "admin" + ":" + "secret";

		byte[] encodedAuth = Base64.encodeBase64(userpass.getBytes(Charset.forName("US-ASCII")));
		String authHeader = "Basic " + new String(encodedAuth);
		get.setHeader("AUTHORIZATION", authHeader);
		get.setHeader("Content-Type", "application/json");

		try (CloseableHttpClient client = HttpClientBuilder.create().build();
				CloseableHttpResponse response = client.execute(get)) {
			ResponseHandler<String> body = new BasicResponseHandler();

			return new RestResponse(response.getStatusLine().getStatusCode(), body.handleResponse(response));
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}

	}

	public static RestResponse performRequest(HttpUriRequest method) {

		CloseableHttpResponse response = null;

		try (CloseableHttpClient client = HttpClientBuilder.create().build()) {
			response = client.execute(method);
			ResponseHandler<String> body = new BasicResponseHandler();
			return new RestResponse(response.getStatusLine().getStatusCode(), body.handleResponse(response));

		}

		catch (Exception e) {

			throw new RuntimeException(e.getMessage(), e);
		}

	}

	public static HttpEntity getHttpEntity(Object content, ContentType type) {

		if (content instanceof String)
			return new StringEntity((String) content, type);

		else if (content instanceof File)
			return new FileEntity((File) content, type);
		else
			throw new RuntimeException("Entity type not found");
	}

	public static Header[] getCustomHeaders(Map<String, String> headers) {

		Header[] customHeaders = new Header[headers.size()];

		int i = 0;

		for (String key : headers.keySet()) {
			customHeaders[i++] = new BasicHeader(key, headers.get(key));
		}
		return customHeaders;

	}

	public static RestResponse perform_put(URI uri, Object content, ContentType type, Map<String, String> headers) {

		HttpUriRequest put = RequestBuilder.put(uri).setEntity(getHttpEntity(content, type)).build();
		String userpass = "admin" + ":" + "secret";

		byte[] encodedAuth = Base64.encodeBase64(userpass.getBytes(Charset.forName("US-ASCII")));
		String authHeader = "Basic" + new String(encodedAuth);
		put.setHeader("AUTHORIZATION", authHeader);
		put.setHeader("Content-Type", "application/json");

		if (null != headers) {

			put.setHeaders(getCustomHeaders(headers));
		}

		return performRequest(put);

	}

	public static RestResponse perform_put(String uri, Object content, ContentType type, Map<String, String> headers) {

		try {
			return perform_put(new URI(uri), content, type, headers);
		} catch (URISyntaxException e) {
			throw new RuntimeException(e.getMessage(), e);
		}

	}
}
