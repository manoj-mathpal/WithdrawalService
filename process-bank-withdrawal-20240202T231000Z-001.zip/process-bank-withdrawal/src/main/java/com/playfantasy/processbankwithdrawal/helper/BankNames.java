package com.playfantasy.processbankwithdrawal.helper;

import com.playfantasy.processbankwithdrawal.exception.BankNotFoundException;

public class BankNames {

	public static String bankFinder(String ifsc_no) {

		String bank_name = null;

		if (ifsc_no.substring(0, 4).equals("PUNB")) {
			bank_name = "Punjab National Bank";
		}

		else if (ifsc_no.substring(0, 4).equals("SBIN")) {
			bank_name = "STATE BANK OF INDIA";

		}

		else if (ifsc_no.substring(0, 4).equals("UTBI")) {
			bank_name = "UNITED BANK OF INDIA";

		}

		else if (ifsc_no.substring(0, 4).equals("UBIN")) {
			bank_name = "UNION BANK OF INDIA";

		}

		else if (ifsc_no.substring(0, 4).equals("PYTM")) {
			bank_name = "PAYTM BANK";

		}

		else if (ifsc_no.substring(0, 4).equals("KKBK")) {
			bank_name = "KOTAK MAHINDRA BANK";

		}

		else if (ifsc_no.substring(0, 4).equals("CORP")) {
			bank_name = "CORPORATION BANK";

		} else if (ifsc_no.substring(0, 4).equals("HDFC")) {
			bank_name = "HDFC BANK";

		} else if (ifsc_no.substring(0, 4).equals("BKID")) {
			bank_name = "BANK OF INDIA";

		} else if (ifsc_no.substring(0, 4).equals("UCBA")) {
			bank_name = "UCO BANK";

		} else if (ifsc_no.substring(0, 4).equals("BARB")) {
			bank_name = "BANK OF BARODA";

		} else if (ifsc_no.substring(0, 4).equals("UTIB")) {
			bank_name = "AXIS BANK";

		} else if (ifsc_no.substring(0, 4).equals("FDRL")) {
			bank_name = "THE FEDERAL BANK LTD";

		} else if (ifsc_no.substring(0, 4).equals("YESB")) {
			bank_name = "YES BANK";

		} else if (ifsc_no.substring(0, 4).equals("IDIB")) {
			bank_name = "INDIAN BANK";

		} else if (ifsc_no.substring(0, 4).equals("VIJB")) {
			bank_name = "VIJAYA BANK";

		} else if (ifsc_no.substring(0, 4).equals("CNRB")) {
			bank_name = "CANARA BANK ";

		} else if (ifsc_no.substring(0, 4).equals("ICIC")) {
			bank_name = "ICICI BANK";

		} else if (ifsc_no.substring(0, 4).equals("WBSC")) {
			bank_name = "WEST BENGAL STATE COOPERATIVE BANK";

		} else if (ifsc_no.substring(0, 4).equals("ALLA")) {
			bank_name = "ALLAHABAD BANK";

		} else if (ifsc_no.substring(0, 4).equals("AIRP")) {
			bank_name = "AIRTEL PAYMENTS BANK LIMITED";

		}

		else if (ifsc_no.substring(0, 4).equals("NTBL")) {
			bank_name = "Nainital Bank Limited";

		} else if (ifsc_no.substring(0, 4).equals("JAKA")) {
			bank_name = "THE JAMMU AND KASHMIR BANK LTD";

		} else if (ifsc_no.substring(0, 4).equals("IBKL")) {
			bank_name = "IDBI BANK LTD";

		} else if (ifsc_no.substring(0, 4).equals("IOBA")) {
			bank_name = "INDIAN OVERSEAS BANK";

		} else if (ifsc_no.substring(0, 4).equals("LAVB")) {
			bank_name = "LAXMI VILAS BANK";

		} else if (ifsc_no.substring(0, 4).equals("SCBL")) {
			bank_name = "STANDARD CHARTERED BANK";

		} else if (ifsc_no.substring(0, 4).equals("INDB")) {
			bank_name = "INDUSIND BANK LTD";

		} else if (ifsc_no.substring(0, 4).equals("ANDB")) {
			bank_name = "ANDHRA BANK";

		} else if (ifsc_no.substring(0, 4).equals("DBSS")) {
			bank_name = "DBS BANK LTD";

		}

		else if (ifsc_no.substring(0, 4).equals("CBIN")) {
			bank_name = "CENTRAL BANK OF INDIA";

		}

		else if (ifsc_no.substring(0, 4).equals("KVBL")) {
			bank_name = "KARUR VYSYA BANK";

		}

		else if (ifsc_no.substring(0, 4).equals("SRCB")) {
			bank_name = "THE SARASWAT CO-OPERATIVE BANK";

		}

		else if (ifsc_no.substring(0, 4).equals("MAHG")) {
			bank_name = "MAHARASHTRA GRAMIN BANK";

		} else if (ifsc_no.substring(0, 4).equals("ORBC")) {
			bank_name = "ORIENTAL BANK OF COMMERCE";

		}

		else if (ifsc_no.substring(0, 4).equals("CITI")) {
			bank_name = "CITI BANK";

		} else if (ifsc_no.substring(0, 4).equals("CIUB")) {
			bank_name = "CITY UNION BANK";

		} else if (ifsc_no.substring(0, 4).equals("SYNB")) {
			bank_name = "SYNDICATE BANK";

		} else if (ifsc_no.substring(0, 4).equals("MAHB")) {
			bank_name = "BANK OF MAHARASHTRA";

		} else if (ifsc_no.substring(0, 4).equals("KARB")) {
			bank_name = "KARNATAKA BANK";

		} else if (ifsc_no.substring(0, 4).equals("AUBL")) {
			bank_name = "AU SMALL FINANCE BANK";

		} else if (ifsc_no.substring(0, 4).equals("BKDN")) {
			bank_name = "DENA BANK";

		} else if (ifsc_no.substring(0, 4).equals("PSIB")) {
			bank_name = "PUNJAB AND SIND BANK";

		} else if (ifsc_no.substring(0, 4).equals("SIBL")) {
			bank_name = "SOUTH INDIAN BANK";

		} else if (ifsc_no.substring(0, 4).equals("RATN")) {
			bank_name = "RBL BANK LIMITED";

		} else if (ifsc_no.substring(0, 4).equals("BDBL")) {
			bank_name = "BANDHAN BANK LIMITED";

		} else if (ifsc_no.substring(0, 4).equals("IDFB")) {
			bank_name = "IDFC BANK LIMITED";

		} else if (ifsc_no.substring(0, 4).equals("SBHY")) {
			bank_name = "STATE BANK OF HYDERABAD";

		} else if (ifsc_no.substring(0, 4).equals("TMBL")) {
			bank_name = "TAMILNAD MERCANTILE BANK";

		} else if (ifsc_no.substring(0, 4).equals("PJSB")) {
			bank_name = "GOPINATH PATIL PARSIK JANATA SAHAKARI BANK";

		} else if (ifsc_no.substring(0, 4).equals("KVGB")) {
			bank_name = "KARNATAKA VIKAS GRAMEENA BANK";

		}

		else {
	
		throw new BankNotFoundException(ifsc_no);
		
		}
		return bank_name;

	}

}
