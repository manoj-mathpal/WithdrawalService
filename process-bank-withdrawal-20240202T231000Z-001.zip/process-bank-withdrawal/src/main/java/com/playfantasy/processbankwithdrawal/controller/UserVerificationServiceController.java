package com.playfantasy.processbankwithdrawal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.playfantasy.processbankwithdrawal.model.Verification;
import com.playfantasy.processbankwithdrawal.service.UserVerificationService;

@RestController
public class UserVerificationServiceController {

	@Autowired
	private UserVerificationService obj;

	@GetMapping(path = "/bankwithdrawal/user/approve/{withdrawId}/{type}")
	public void verifyUser(@PathVariable int withdrawId, @PathVariable int type) {

		obj.userVerif(withdrawId, type);
}

	@GetMapping(path = "/bankwithdrawal/verify/{user_id}")
	public String userNetwork(@PathVariable String user_id) {

		String str = obj.captureBonusApiInfo(user_id);
		return str;
	}

	@GetMapping(path = "/bankwithdrawal/summary/{withdrawId}")
	public Verification withdrawSummary(@PathVariable int withdrawId) {

		Verification verify = obj.callWithdrawUserSummaryApi(withdrawId);
		return verify;

	}

}
