package com.playfantasy.processbankwithdrawal.model;

public class User {

	private int id;
	private double withdrawBucket;
	private boolean mobileVerified;
	private boolean emailVerified;
	private String panVerified;
	private String userStatus;
	private String message;

	public User() {
		super();
	}

	public User(double withdrawBucket, boolean mobileVerified, boolean emailVerified, String panVerified,
			String userStatus, String message) {
		super();
		this.withdrawBucket = withdrawBucket;
		this.mobileVerified = mobileVerified;
		this.emailVerified = emailVerified;
		this.panVerified = panVerified;
		this.userStatus = userStatus;
		this.message = message;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getWithdrawBucket() {
		return withdrawBucket;
	}

	public void setWithdrawBucket(double withdrawBucket) {
		this.withdrawBucket = withdrawBucket;
	}

	public boolean getMobileVerified() {
		return mobileVerified;
	}

	public void setMobileVerified(boolean mobileVerified) {
		this.mobileVerified = mobileVerified;
	}

	public boolean getEmailVerified() {
		return emailVerified;
	}

	public void setEmailVerified(boolean emailVerified) {
		this.emailVerified = emailVerified;
	}

	public String getPanVerified() {
		return panVerified;
	}

	public void setPanVerified(String panVerified) {
		this.panVerified = panVerified;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", withdrawBucket=" + withdrawBucket + ", mobileVerified=" + mobileVerified
				+ ", emailVerified=" + emailVerified + ", panVerified=" + panVerified + ", userStatus=" + userStatus
				+ ", message=" + message + "]";
	}

}
