package com.playfantasy.processbankwithdrawal.controller;

import java.io.IOException;

import javax.mail.MessagingException;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.playfantasy.processbankwithdrawal.service.MailService;

@RestController
public class MailController {

	@Autowired
	MailService service;

	@GetMapping(path = "/send-email")
	public String emailApprovedList() throws MessagingException, IOException, ParseException {
        service.sendEmail();
		return "email sent";
	}

}
